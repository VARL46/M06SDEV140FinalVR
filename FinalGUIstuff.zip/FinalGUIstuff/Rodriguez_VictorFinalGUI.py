#Victor Rodriguez
#SDEV 153
#this GUI will allow people to select from a few items, custimize them and determine how many they want. At the end, the GUI will display a summary screen for the items and their price.

from breezypythongui import EasyFrame

class TacoTuesday(EasyFrame):

    def __init__(self):
        tacoNumber=0
        EasyFrame.__init__(self, title="Taco Tuesday")
        self.addLabel(text="Menu", row=0, column=1)
        self.addLabel(text="Tacos", row=1, column=0)
        self.addButton(text="Add item", row=1,column=2, columnspan=2, command=self.addTaco)
        self.addButton(text="Remove", row=1,column=3, columnspan=2, command=self.removeTaco)                               #this is a portion of my master plan. At the moment I will need to figure out two things
        self.outputField = self.addFloatField(value="0.0", row=1, column=1, width=8, precision=2, state="readonly")         #1. how to add an output field for each unique item
        self.addLabel(text="Burritos", row=2, column=0)                                                                     #2. How to get the tacoNumber to remain
        self.addLabel(text="Enchiladas", row=2, column=0)
        self.addLabel(text="Dinners", row=4, column=1)
        self.addLabel(text="All dinners come with rice and beans.", row=5, column=1)
        self.addLabel(text="Taco Dinner", row=6, column=0)
        self.addLabel(text="Burrito Dinner", row=7, column=0)
        self.addLabel(text="Enchilada Dinner", row=8, column=0)

    def addTaco(self):
        tacoNumber =+ 1
        self.outputField.setNumber(tacoNumber)
    
    def removeTaco(self):
        tacoNumber =- 1
        self.outputField.setNumber(tacoNumber)



def main():                                 
    TacoTuesday().mainloop()

if __name__ =="__main__":
    main()